import { AppDataSource } from "../config/db";
import { Estudiante } from "../entities/Estudiante.entity";

// Crear el repositorio 
const estudianteRepository = AppDataSource.getRepository(Estudiante);
 
// C = Create, R = Read, U = Upada, D = Delete

// Leer todos los estudiantes
export const srvGetEstudiantes = async () => {

    //Select * from carreras arder by id_carrera desc;
    const estudiante = await estudianteRepository.find({
        order:{ nombreEstudiante: 'ASC' }
    });

    return estudiante;

}

// Crear una nueva estudiante
export const srvCreateEstudiante = async (pNombreEstudiante: string) => {

    const nuevaEstudiante = new Estudiante();

    nuevaEstudiante.nombreEstudiante = pNombreEstudiante;

    return await estudianteRepository.save(nuevaEstudiante);

}

//Obtener una estudiante
export const srvGetEstudianteByID = async (pIdEstudiante: number) => {

    const carrera = await estudianteRepository.findOne({
        where: { idEstudiante: pIdEstudiante }
    })

    return estudianteRepository;

}

// Actualizar estudiante
export const srvUpdateEstudiante = async (pIdEstudiante: number, pNombreEstudiante: string) => {

    // Buscar la carrera
    const estudiante = await estudianteRepository.findOne({
        where: { idEstudiante: pIdEstudiante}
    })

    //Validación
    if(!estudiante) return null;

    estudiante.nombreEstudiante = pNombreEstudiante;

    return await estudianteRepository.save(estudiante);

}

//Eliminar estudiante
export const srvDeleteEstudiante = async (pIdEstudiante: number) => {

        // Buscar la carrera
        const estudiante = await estudianteRepository.findOne({
            where: { idEstudiante: pIdEstudiante}
        })
    
        //Validación
        if(!estudiante) return null;
    
        return await estudianteRepository.remove(estudiante);

}