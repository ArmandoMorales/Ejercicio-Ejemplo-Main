import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity({ name: 'estudiante'})
export class Estudiante{

    //Definir todos los campos
    @PrimaryGeneratedColumn({ name: 'id:estudiante'})
    idEstudiante: number;

    @Column({ name: 'nombre_estudiante', nullable: false})
    nombreEstudiante: string}