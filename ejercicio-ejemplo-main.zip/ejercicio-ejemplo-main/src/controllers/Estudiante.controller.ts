import { Request, Response } from "express";



import { 
    srvCreateEstudiante,
    srvGetEstudianteByID,
    srvGetEstudiantes,
    srvDeleteEstudiante
} from "../services/Estudiante.services";


// OBTENER TODAS LOS Estudiante
export const srvGetEstudiante = async (req: Request, res: Response) => {

    try {
        const estudiante = await srvGetEstudiantes();
        res.status(200).json(estudiante)
    } catch (error) {
        console.log('Error al obtener las carreras' + error)
    }

}

// OBTENER UN Estudiante POR ID
export const getEstudiante = async(req: Request, res: Response) => {

    try {
        const { idEstudiante } = req.params;
    
        const estudiante = await srvGetEstudianteByID(+idEstudiante);
    
        if(!estudiante) res.status(404).json({ message: 'No se encontró la carrera con ID ' + idEstudiante });
    
        res.status(200).json(estudiante);
    
    } catch (error) {

        console.log('Error al obtener la carrera' + error)
    
    }

}

// CREAR UN Estudiante
export const createEstudiantes= async (req: Request, res: Response) => {

    try {

        const { nombreEstudiante } = req.body;

        const estudiante = await srvCreateEstudiante(nombreEstudiante);

        res.status(201).json(estudiante)

    } catch (error) {
        console.log('Error al crear la carrera' + error)
    }

}

// ACTUALIZAR UN ESTUDIANTE
export const updateEstudiante = async (req: Request, res: Response) => {

    const { id } = req.params; // const datos = req.params; // const id = datos.id;
    const { nombreEstudiante } = req.body;

    try {
        const estudiante = await srvGetEstudianteByID(+id);

        if(!estudiante) res.status(404).json({ message: 'No se encontró al estudiante con ID ' + id });

        const estudianteUpdated = await srvCreateEstudiante(nombreEstudiante);

        res.status(200).json(estudianteUpdated)

    }
    catch (error) {
        console.log('Error al actualizar el estudiante' + error)
    }

}

// ELIMINAR UN ESTUDIANTE
export const deleteEstudiantes = async (req: Request, res: Response) => {
    const { id } = req.params;

    try {
        const estudiante = await srvGetEstudianteByID(+id);

        if(!estudiante) res.status(404).json({ message: 'No se encontró al estudiante con ID ' + id });

        // eliminar AL ESTUIANTE 
        await srvDeleteEstudiante(+id);

        res.status(200).json({ message: 'Estudiante eliminada' })

    }
    catch (error) {
        console.log('Error al eliminar al estudiante' + error)
    }

}