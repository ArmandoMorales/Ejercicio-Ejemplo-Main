import { Router } from 'express';
import {  getEstudiante, createEstudiantes,updateEstudiante, deleteEstudiantes  } from '../controllers/Estudiante.controller';


const router = Router ();

router.get('/',)
router.get('/:id', getEstudiante);
router.post('/', createEstudiantes);
router.put('/:id', updateEstudiante);
router.delete('/:id', deleteEstudiantes);

export default router;